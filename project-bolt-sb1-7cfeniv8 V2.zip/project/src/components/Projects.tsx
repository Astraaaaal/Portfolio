import React from 'react';
import { ChevronRight } from 'lucide-react';

interface ProjectCardProps {
  title: string;
  image: string;
  description: string;
  featured?: boolean;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ title, image, description, featured = false }) => {
  return (
    <div className={`bg-white rounded-lg shadow-md overflow-hidden ${featured ? 'col-span-2' : ''}`}>
      <div className="relative">
        <img 
          src={image} 
          alt={title} 
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-2 right-2">
          <span className="bg-yellow-500 text-xs text-white font-semibold px-2 py-1 rounded">
            Projet
          </span>
        </div>
      </div>
      <div className="p-4">
        <h4 className="text-xl font-bold mb-2">{title}</h4>
        <p className="text-gray-700 text-sm mb-4 line-clamp-3">{description}</p>
        
        <div className="mb-4">
          <h5 className="font-semibold mb-1">Descriptif</h5>
          <p className="text-gray-700 text-sm line-clamp-2">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce gravida, dui consequat non mattis scelerisque.
          </p>
        </div>
        
        <div className="mb-4">
          <h5 className="font-semibold mb-1">Étapes</h5>
          <p className="text-gray-700 text-sm line-clamp-2">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce gravida, dui consequat non mattis scelerisque.
          </p>
        </div>
        
        <button className="bg-yellow-500 hover:bg-yellow-600 text-white text-sm font-semibold py-2 px-4 rounded inline-flex items-center transition-colors">
          <span>View all</span>
          <ChevronRight className="ml-1 h-4 w-4" />
        </button>
      </div>
    </div>
  );
};

const Projects: React.FC = () => {
  const projects = [
    {
      id: 1,
      title: "PROJET N°1",
      image: "https://images.pexels.com/photos/5082579/pexels-photo-5082579.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce gravida, dui consequat non mattis scelerisque."
    },
    {
      id: 2,
      title: "PROJET N°2",
      image: "https://images.pexels.com/photos/5082579/pexels-photo-5082579.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce gravida, dui consequat non mattis scelerisque."
    },
    {
      id: 3,
      title: "PROJET N°3",
      image: "https://images.pexels.com/photos/5082579/pexels-photo-5082579.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce gravida, dui consequat non mattis scelerisque."
    }
  ];

  return (
    <section id="projets" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-16 pb-2 border-b border-gray-200">
          PROJETS
        </h2>
        
        <div className="mb-16">
          <div className="bg-white rounded-lg shadow-md p-8 max-w-4xl mx-auto">
            <h3 className="text-2xl font-bold mb-4 text-center">NOS REALISATIONS</h3>
            <p className="text-gray-700 mb-6 text-center">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce gravida, dui consequat non mattis scelerisque, leo justo eleifend ex, et porttitor magna est vitae ipsum.
            </p>
            <div className="flex justify-center">
              <button className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-6 rounded-md inline-flex items-center transition-colors">
                <span>Découvrir</span>
                <ChevronRight className="ml-1 h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <ProjectCard 
              key={project.id}
              title={project.title}
              image={project.image}
              description={project.description}
              featured={index === 0}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;