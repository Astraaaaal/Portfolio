import React from 'react';
import { Download } from 'lucide-react';

const Resume: React.FC = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-16 pb-2 border-b border-gray-200">
          MON CV
        </h2>
        
        <div className="flex justify-center">
          <div className="w-full max-w-2xl bg-white shadow-lg rounded-lg overflow-hidden">
            <div className="bg-blue-500 text-white px-6 py-12 flex items-center justify-center">
              <div className="text-center">
                <h3 className="text-2xl font-bold mb-4">TELECHARGER</h3>
                <div className="flex justify-center">
                  <img
                    src="https://images.pexels.com/photos/7551442/pexels-photo-7551442.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                    alt="Abstract CV visualization"
                    className="w-full max-w-sm rounded-md"
                  />
                </div>
              </div>
            </div>
            <div className="p-6 text-center">
              <p className="text-gray-700 mb-6">
                Téléchargez mon CV pour en savoir plus sur mon parcours et mes compétences.
              </p>
              <button className="bg-yellow-500 hover:bg-yellow-600 text-gray-900 font-semibold py-3 px-8 rounded-full inline-flex items-center transition-colors">
                <Download className="mr-2 h-5 w-5" />
                <span>Télécharger mon CV</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Resume;