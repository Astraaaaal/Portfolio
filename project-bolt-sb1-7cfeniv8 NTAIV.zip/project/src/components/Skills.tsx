import React from 'react';
import { ChevronRight } from 'lucide-react';

interface SkillCardProps {
  title: string;
  description: string;
  image: string;
}

const SkillCard: React.FC<SkillCardProps> = ({ title, description, image }) => {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
      <div className="flex items-center gap-4 p-4">
        <img 
          src={image} 
          alt={title} 
          className="w-16 h-16 object-cover rounded"
        />
        <div>
          <h4 className="font-bold mb-1">{title}</h4>
          <p className="text-gray-600 text-sm">{description}</p>
          <button className="mt-2 text-blue-600 text-sm font-medium inline-flex items-center">
            <span>Détails</span>
            <ChevronRight className="ml-1 h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

const Skills: React.FC = () => {
  const skills = [
    {
      id: 1,
      title: "FORTNITE",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce gravida.",
      image: "https://images.pexels.com/photos/1749900/pexels-photo-1749900.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: 2,
      title: "FORTNITE",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce gravida.",
      image: "https://images.pexels.com/photos/1749900/pexels-photo-1749900.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: 3,
      title: "FORTNITE",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce gravida.",
      image: "https://images.pexels.com/photos/1749900/pexels-photo-1749900.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: 4,
      title: "FORTNITE",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce gravida.",
      image: "https://images.pexels.com/photos/1749900/pexels-photo-1749900.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: 5,
      title: "FORTNITE",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce gravida.",
      image: "https://images.pexels.com/photos/1749900/pexels-photo-1749900.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: 6,
      title: "FORTNITE",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce gravida.",
      image: "https://images.pexels.com/photos/1749900/pexels-photo-1749900.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    }
  ];

  return (
    <section id="compétences" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-16 pb-2 border-b border-gray-200">
          COMPETENCES
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl mx-auto">
          {skills.map((skill) => (
            <SkillCard 
              key={skill.id}
              title={skill.title}
              description={skill.description}
              image={skill.image}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;