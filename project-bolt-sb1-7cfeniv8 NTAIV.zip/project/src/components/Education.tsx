import React from 'react';

interface EducationItemProps {
  title: string;
  period?: string;
  description: string;
  images?: string[];
}

const EducationItem: React.FC<EducationItemProps> = ({ title, period, description, images }) => {
  return (
    <div className="mb-12">
      <h3 className="text-2xl font-bold mb-4">{title}</h3>
      <div className="flex flex-col md:flex-row gap-8">
        {images && images.length > 0 && (
          <div className="w-full md:w-1/3 flex flex-col gap-4">
            {images.map((image, index) => (
              <img 
                key={index}
                src={image}
                alt={`${title} illustration ${index + 1}`}
                className="w-full h-48 object-cover rounded-lg shadow-md"
              />
            ))}
          </div>
        )}
        <div className={`w-full ${images && images.length > 0 ? 'md:w-2/3' : ''}`}>
          {period && <p className="text-sm text-gray-500 mb-2">{period}</p>}
          <p className="text-gray-700">{description}</p>
        </div>
      </div>
    </div>
  );
};

const Education: React.FC = () => {
  const educationData = [
    {
      title: "ETUDES",
      items: [
        {
          title: "COLLEGE",
          description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce gravida, dui consequat non mattis scelerisque, leo justo eleifend ex, et porttitor magna est vitae ipsum. Sed scelerisque, ipsum vitae ornare cursus, diam massa cursus felis, non vulputate ex nulla ac nibh. Morbi vitae urna sit amet nisi bibendum elementum.",
          images: [
            "https://images.pexels.com/photos/301926/pexels-photo-301926.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
            "https://images.pexels.com/photos/5428003/pexels-photo-5428003.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
          ]
        },
        {
          title: "LYCEE",
          description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce gravida, dui consequat non mattis scelerisque, leo justo eleifend ex, et porttitor magna est vitae ipsum. Sed scelerisque, ipsum vitae ornare cursus, diam massa cursus felis, non vulputate ex nulla ac nibh."
        }
      ]
    },
    {
      title: "ACTUELLEMENT",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce gravida, dui consequat non mattis scelerisque, leo justo eleifend ex, et porttitor magna est vitae ipsum. Sed scelerisque, ipsum vitae ornare cursus, diam massa cursus felis, non vulputate ex nulla ac nibh. Morbi vitae urna sit amet nisi bibendum elementum.",
      items: [
        {
          description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce gravida, dui consequat non mattis scelerisque, leo justo eleifend ex, et porttitor magna est vitae ipsum. Sed scelerisque, ipsum vitae ornare cursus, diam massa cursus felis, non vulputate ex nulla ac nibh.",
          images: ["https://images.pexels.com/photos/943096/pexels-photo-943096.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"]
        }
      ]
    },
    {
      title: "EN SUITE ?",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce gravida, dui consequat non mattis scelerisque, leo justo eleifend ex, et porttitor magna est vitae ipsum. Sed scelerisque, ipsum vitae ornare cursus, diam massa cursus felis, non vulputate ex nulla ac nibh. Morbi vitae urna sit amet nisi bibendum elementum."
    }
  ];

  return (
    <section id="parcours" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-16 pb-2 border-b border-gray-200">
          PARCOURS
        </h2>
        
        {educationData.map((section, index) => (
          <div key={index} className="mb-16">
            <h3 className="text-3xl font-bold text-center mb-10">{section.title}</h3>
            
            {section.description && (
              <p className="text-gray-700 mb-8 max-w-4xl mx-auto text-center">
                {section.description}
              </p>
            )}
            
            {section.items && section.items.map((item, idx) => (
              <EducationItem 
                key={idx}
                title={item.title || ''}
                description={item.description}
                images={item.images}
              />
            ))}
          </div>
        ))}
      </div>
    </section>
  );
};

export default Education;