import React, { useState } from 'react';
import { Download } from 'lucide-react';

const Resume: React.FC = () => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-16 pb-2 border-b border-gray-200">
          MON CV
        </h2>
        
        <div className="flex justify-center">
          <div 
            className="relative w-full max-w-2xl overflow-hidden rounded-2xl"
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
          >
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/7551442/pexels-photo-7551442.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                alt="Abstract CV visualization"
                className={`w-full h-[400px] object-cover transition-all duration-300 ${
                  isHovered ? 'blur-sm scale-105' : ''
                }`}
              />
              <div 
                className={`absolute inset-0 bg-black/30 transition-opacity duration-300 ${
                  isHovered ? 'opacity-100' : 'opacity-0'
                }`}
              />
            </div>
            
            <div className="absolute inset-0 flex items-center justify-center">
              <button 
                className={`
                  relative 
                  group 
                  bg-transparent 
                  border-2 
                  border-white 
                  text-white 
                  font-semibold 
                  py-3 
                  px-8 
                  rounded-full 
                  overflow-hidden
                  transition-all
                  duration-300
                  ${isHovered ? 'scale-110' : ''}
                `}
              >
                <span className="relative z-10 flex items-center">
                  <Download className="mr-2 h-5 w-5" />
                  <span>TELECHARGER</span>
                </span>
                <div 
                  className={`
                    absolute 
                    inset-0 
                    bg-white 
                    transition-all 
                    duration-300
                    ${isHovered ? 'opacity-100' : 'opacity-0'}
                  `}
                  style={{
                    transform: isHovered ? 'scaleX(1)' : 'scaleX(0)',
                    transformOrigin: 'left',
                  }}
                />
                <span 
                  className={`
                    absolute 
                    inset-0 
                    flex 
                    items-center 
                    justify-center 
                    text-black
                    transition-opacity
                    duration-300
                    ${isHovered ? 'opacity-100' : 'opacity-0'}
                  `}
                >
                  <Download className="mr-2 h-5 w-5" />
                  <span>TELECHARGER</span>
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Resume;