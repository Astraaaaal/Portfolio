import React from 'react';

const About: React.FC = () => {
  return (
    <section id="à propos" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-16 pb-2 border-b border-gray-200">
          A PROPOS
        </h2>
        
        <div className="mb-20">
          <h3 className="text-2xl font-bold mb-8">Qui suis-je ?</h3>
          <div className="flex flex-col md:flex-row gap-8">
            <div className="w-full md:w-2/3">
              <p className="text-gray-700 mb-4">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce gravida, dui consequat non mattis scelerisque, leo justo eleifend ex, et porttitor magna est vitae ipsum. Sed scelerisque, ipsum vitae ornare cursus, diam massa cursus felis, non vulputate ex nulla ac nibh. Morbi vitae urna sit amet nisi bibendum elementum. 
              </p>
              <p className="text-gray-700 mb-4">
                Donec varius felis vel magna tempus, in lobortis enim finibus. Vestibulum nec est a massa lacinia cursus sit amet et tortor. Nam congue dignissim risus, a dignare ligula tincidunt eu. Mauris eleifend, leo ac tempus convallis, orci nulla dapibus massa, a pulvinar metus dolor ut elit. 
              </p>
              <p className="text-gray-700 mb-4">
                Donec varius felis vel magna tempus, in lobortis enim finibus. Vestibulum nec est a massa lacinia cursus sit amet et tortor. Nam congue dignissim risus, a dignare ligula tincidunt eu. Mauris eleifend, leo ac tempus convallis, orci nulla dapibus massa, a pulvinar metus dolor ut elit. 
              </p>
              <div className="mt-4">
                <span className="inline-block mr-2 text-sm font-medium text-gray-700">
                  Mon CV
                </span>
                <svg className="inline w-5 h-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </div>
            </div>
            <div className="w-full md:w-1/3">
              <img 
                src="https://images.pexels.com/photos/323705/pexels-photo-323705.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                alt="Building" 
                className="w-full h-64 object-cover rounded-lg shadow-md"
              />
              <p className="text-xs text-gray-500 mt-2 text-center">
                Lorem ipsum dolor sit amet, consectetur
              </p>
            </div>
          </div>
        </div>
        
        <div>
          <h3 className="text-2xl font-bold mb-8 text-center">Pourquoi moi ?</h3>
          <div className="max-w-3xl mx-auto">
            <p className="text-gray-700 mb-4 text-center">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce gravida, dui consequat non mattis scelerisque, leo justo eleifend ex, et porttitor magna est vitae ipsum. Sed scelerisque, ipsum vitae ornare cursus, diam massa cursus felis, non vulputate ex nulla ac nibh. Morbi vitae urna sit amet nisi bibendum elementum. 
            </p>
            <p className="text-gray-700 mb-4 text-center">
              Donec varius felis vel magna tempus, in lobortis enim finibus. Vestibulum nec est a massa lacinia cursus sit amet et tortor. Nam congue dignissim risus, a dignare ligula tincidunt eu. Mauris eleifend, leo ac tempus convallis, orci nulla dapibus massa, a pulvinar metus dolor ut elit. 
            </p>
            <div className="mt-8 text-center">
              <button className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold py-2 px-6 rounded-md transition-colors">
                Me contacter
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;