import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen bg-gray-800 flex items-center">
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-30"
        style={{ 
          backgroundImage: "url('https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1')"
        }}
      ></div>
      
      <div className="container mx-auto px-4 z-10 py-20 md:py-0">
        <div className="flex flex-col md:flex-row items-center">
          <div className="w-full md:w-1/2 text-center md:text-left">
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-4">
              PORTFOLIO
            </h1>
            <p className="text-xl text-white opacity-80 mb-8">
              Bienvenue sur mon portfolio de développeur web
            </p>
            <button className="bg-yellow-500 hover:bg-yellow-600 text-gray-900 font-semibold py-3 px-8 rounded-full transition-colors">
              Découvrir
            </button>
          </div>
          <div className="w-full md:w-1/2 mt-12 md:mt-0">
            <img 
              src="https://images.pexels.com/photos/8467013/pexels-photo-8467013.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
              alt="Illustration" 
              className="w-full max-w-lg mx-auto"
            />
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-0 left-0 right-0">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
          <path 
            fill="#ffffff" 
            fillOpacity="1" 
            d="M0,128L48,128C96,128,192,128,288,154.7C384,181,480,235,576,234.7C672,235,768,181,864,165.3C960,149,1056,171,1152,176C1248,181,1344,171,1392,165.3L1440,160L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
          ></path>
        </svg>
      </div>
      
      <div className="absolute bottom-24 left-1/2 transform -translate-x-1/2 text-center">
        <div className="bg-white shadow-lg rounded-lg py-4 px-8">
          <h2 className="text-2xl font-bold text-gray-800">WORK IN PROGRESS</h2>
        </div>
      </div>
    </section>
  );
};

export default Hero;