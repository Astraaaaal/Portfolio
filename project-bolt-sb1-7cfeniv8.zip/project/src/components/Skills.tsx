import React from 'react';
import { ChevronRight } from 'lucide-react';

interface SkillCardProps {
  title: string;
  description: string;
  image: string;
}

const SkillCard: React.FC<SkillCardProps> = ({ title, description, image }) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="relative">
        <img 
          src={image} 
          alt={title} 
          className="w-full h-48 object-cover"
        />
      </div>
      <div className="p-4">
        <h4 className="text-xl font-bold mb-2">{title}</h4>
        <p className="text-gray-700 text-sm mb-4">{description}</p>
        <button className="bg-yellow-500 hover:bg-yellow-600 text-white text-sm font-semibold py-2 px-4 rounded inline-flex items-center transition-colors">
          <span>Détails</span>
          <ChevronRight className="ml-1 h-4 w-4" />
        </button>
      </div>
    </div>
  );
};

const Skills: React.FC = () => {
  const skills = [
    {
      id: 1,
      title: "COMPETENCE 1",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce gravida, dui consequat non mattis scelerisque, leo justo eleifend ex, et porttitor magna est vitae ipsum.",
      image: "https://images.pexels.com/photos/1749900/pexels-photo-1749900.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: 2,
      title: "COMPETENCE 2",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce gravida, dui consequat non mattis scelerisque, leo justo eleifend ex, et porttitor magna est vitae ipsum.",
      image: "https://images.pexels.com/photos/1749900/pexels-photo-1749900.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    }
  ];

  return (
    <section id="compétences" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-16 pb-2 border-b border-gray-200">
          COMPETENCES
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {skills.map((skill) => (
            <SkillCard 
              key={skill.id}
              title={skill.title}
              description={skill.description}
              image={skill.image}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;