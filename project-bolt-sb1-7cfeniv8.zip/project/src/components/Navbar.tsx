import React, { useState, useEffect } from 'react';

const Navbar: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 10;
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled);
      }
    };

    document.addEventListener('scroll', handleScroll);
    return () => {
      document.removeEventListener('scroll', handleScroll);
    };
  }, [scrolled]);

  return (
    <header 
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        scrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 flex justify-between items-center">
        <div className="text-xl font-bold">
          <span className={scrolled ? 'text-gray-800' : 'text-white'}>Portfolio</span>
        </div>
        <nav className="hidden md:block">
          <ul className="flex space-x-8">
            {['À propos', 'Parcours', 'Projets', 'Compétences'].map((item) => (
              <li key={item}>
                <a 
                  href={`#${item.toLowerCase()}`} 
                  className={`${
                    scrolled ? 'text-gray-800' : 'text-white'
                  } hover:text-gray-600 transition-colors`}
                >
                  {item}
                </a>
              </li>
            ))}
          </ul>
        </nav>
        <div className="md:hidden">
          <button 
            className={`p-2 rounded-md ${
              scrolled ? 'text-gray-800' : 'text-white'
            }`}
          >
            <span className="block w-6 h-0.5 bg-current mb-1"></span>
            <span className="block w-6 h-0.5 bg-current mb-1"></span>
            <span className="block w-6 h-0.5 bg-current"></span>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Navbar;